create view vemp1 as (select `newdb3`.`emp`.`EMPNO`    AS `EMPNO`,
                             `newdb3`.`emp`.`ENAME`    AS `ENAME`,
                             `newdb3`.`emp`.`JOB`      AS `JOB`,
                             `newdb3`.`emp`.`MGR`      AS `MGR`,
                             `newdb3`.`emp`.`HIREdate` AS `HIREdate`,
                             `newdb3`.`emp`.`SAL`      AS `SAL`,
                             `newdb3`.`emp`.`COMM`     AS `COMM`,
                             `newdb3`.`emp`.`DEPTNO`   AS `DEPTNO`
                      from `newdb3`.`emp`
                      where (`newdb3`.`emp`.`DEPTNO` = 10));

