create view vemsal as (select `newdb3`.`emp`.`EMPNO` AS `EMPNO`,
                              `newdb3`.`emp`.`ENAME` AS `ENAME`,
                              `newdb3`.`emp`.`JOB`   AS `job`,
                              `newdb3`.`emp`.`MGR`   AS `mgr`
                       from `newdb3`.`emp`
                       where (`newdb3`.`emp`.`DEPTNO` = 10));

